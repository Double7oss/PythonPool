def count_in_list(lst, value):
    """Counts how many times 'value' appears in 'lst'."""
    return lst.count(value)
